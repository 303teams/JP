package com.bjtu.dao;

import com.bjtu.pojo.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class UserDaoTest {

//    @Autowired
//    UserDao userDao;

//    @Test
//    void insert() {
//        User user = new User("lzc","111","男","四川");
//        userDao.insert(user);
//    }
//
//    @Test
//    void deleteByName() {
//        userDao.deleteByName("lzc");
//    }
//
//    @Test
//    void findAll() {
//        List<User> users = userDao.findAll();
//        users.forEach(System.out::println);
//    }
//
//    @Test
//    void findByName() {
//        User user = userDao.findByName("11");
//        System.out.println(user);
//    }
}